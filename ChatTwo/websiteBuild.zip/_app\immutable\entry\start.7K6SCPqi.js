import{l as o,a as r}from"../chunks/B3RC9nln.js";export{o as load_css,r as start};
